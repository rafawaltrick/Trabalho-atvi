export default class Produto {
    public nome!: string
}