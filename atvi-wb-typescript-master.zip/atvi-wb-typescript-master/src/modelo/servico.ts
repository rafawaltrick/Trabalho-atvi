export default class Servico {
    public nome!: string
}